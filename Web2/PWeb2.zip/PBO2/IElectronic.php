<?php
// interfaces
interface IElectronic {
    public function setMarek($merek);
    public function setNama($nama);
    public function setStock($stock);
}