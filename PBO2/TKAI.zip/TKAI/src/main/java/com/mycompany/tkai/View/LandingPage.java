package com.mycompany.tkai.View;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

public final class LandingPage extends JFrame implements ActionListener {

    private final JLabel titleLabel;
    private final JLabel descriptionLabel;
    private final JButton loginButton;

    public LandingPage() {
        setTitle("KAI Application");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Title Label
        titleLabel = new JLabel("WELCOME KAI ADMIN", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(titleLabel, BorderLayout.NORTH);

        // Image Display
        imageDisplay();  // Ensures image is displayed

        // play audio
        playWelcomeAudio();

        // Description Label
        descriptionLabel = new JLabel("This is a simple application. Please log in to continue.", SwingConstants.CENTER);
        add(descriptionLabel, BorderLayout.SOUTH);

        // Login Button
        loginButton = new JButton("Login");
        loginButton.addActionListener(this);
        add(loginButton, BorderLayout.PAGE_END);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            // Close the landing page window
            dispose();

            // Open the login form window
            LoginForm loginForm = new LoginForm();
            loginForm.setVisible(true);
        }
    }

    private void imageDisplay() {
        URL location = getClass().getResource("/KAILOGO.png");
        if (location == null) {
            System.err.println("Resource /KAILOGO.png not found.");
            return;
        }

        ImageIcon imageIcon = new ImageIcon(location);
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setHorizontalAlignment(JLabel.CENTER);
        imageLabel.setVerticalAlignment(JLabel.CENTER);

        // Add image label to the frame in a way that it doesn't overlap with other components
        add(imageLabel, BorderLayout.CENTER);

        // Make sure changes are visible
        revalidate();
        repaint();
    }

    private void playWelcomeAudio() {
        try {
            // Load an audio file as a resource stream
            InputStream audioStream = getClass().getResourceAsStream("/welcome.mp3");
            if (audioStream == null) {
                throw new IOException("Audio file not found");
            }

            // Use JLayer's Player to play MP3
            Player player = new Player(audioStream);
            new Thread(() -> {
                try {
                    player.play();
                } catch (JavaLayerException e) {
                    JOptionPane.showMessageDialog(this, "Failed to play audio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }).start();

        } catch (IOException | JavaLayerException e) {
            JOptionPane.showMessageDialog(this, "Failed to play audio: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LandingPage::new);
    }
}
