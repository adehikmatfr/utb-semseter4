/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tkai.Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author macbook
 */
public class DepartureSchedule {
    private List<Itinerary> iternaryList;

    public DepartureSchedule() {
        iternaryList = new ArrayList<>();
    }

    public void addInternary(Itinerary iternary) {
        iternaryList.add(iternary);
    }

    public List<Itinerary> getIternaryList() {
        return iternaryList;
    }

    public void setIternaryList(List<Itinerary> iternaryList) {
        this.iternaryList = iternaryList;
    }
}
