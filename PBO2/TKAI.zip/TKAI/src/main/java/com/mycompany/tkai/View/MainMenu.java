/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tkai.View;

/**
 *
 * @author macbook
 */
import com.mycompany.tkai.Model.DepartureSchedule;
import com.mycompany.tkai.Model.Itinerary;
import java.awt.BorderLayout;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class MainMenu extends JFrame {

    public DepartureSchedule departureSchedule;
    private DefaultTableModel iternityModel;
    private JTable iternityTable;

    private void dataDataDefault() {
        Date departureTime1 = new Date();
        Date arrivalTime1 = new Date();
        Date departureTime2 = new Date();
        Date arrivalTime2 = new Date();
        Date departureTime3 = new Date();
        Date arrivalTime3 = new Date();

        String[] columnNames = {"Train  Number","Departure Station", "Arrival Station", "Departure Time", "Arrival Time", "Ticket Price Include PPn"};
        this.iternityModel = new DefaultTableModel(columnNames, 0);
        this.departureSchedule = new DepartureSchedule();
        this.departureSchedule.addInternary(new Itinerary("TN123", "Station A", "Station B", departureTime1, arrivalTime1, 50.0));
        this.departureSchedule.addInternary(new Itinerary("TN456", "Station C", "Station D", departureTime2, arrivalTime2, 60.0));
        this.departureSchedule.addInternary(new Itinerary("TN789", "Station E", "Station F", departureTime3, arrivalTime3, 70.0));
        this.departureSchedule.addInternary(new Itinerary("TN789", "Station E", "Station F", departureTime3, arrivalTime3, 70.0));
        departureScheduleTable(this.departureSchedule.getIternaryList());
    }

    public MainMenu() {
        setTitle("Main Menu TKAI");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();

        // Create File menu
        JMenu fileMenu = new JMenu("Menu");
        JMenuItem scheduleFrom = new JMenuItem("From Jadwal Keberangkatan");
        JMenuItem exitItem = new JMenuItem("Keluar");

        // Add menu items to File menu
        fileMenu.add(scheduleFrom);
        fileMenu.addSeparator(); // Add separator between Save and Exit
        fileMenu.add(exitItem);

        // Add menus to menu bar
        menuBar.add(fileMenu);

        // Set menu bar for the frame
        setJMenuBar(menuBar);

        // Add action listener for Exit menu item
        exitItem.addActionListener((ActionEvent e) -> {
            // Exit the application
            System.exit(0);
        });

        scheduleFrom.addActionListener((ActionEvent e) -> {
            // Exit the application
            ScheduleForm scheduleForm = new ScheduleForm(this);
        });
        dataDataDefault();

        setVisible(true);
    }

    private void departureScheduleTable(List<Itinerary> itineraryList) {
        // Add data to the table model
        for (Itinerary itinerary : itineraryList) {
            Object[] rowData = {
                itinerary.getTrainNumber(),
                itinerary.getDepartureStation(),
                itinerary.getArrivalStation(),
                itinerary.getDepartureTime(),
                itinerary.getArrivalTime(),
                itinerary.getTicketPrice()
            };
            iternityModel.addRow(rowData);
        }

        // Create a table with the model
        this.iternityTable = new JTable(iternityModel);
        this.iternityTable.enableInputMethods(false);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(iternityTable);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Create a search field
        JTextField searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        searchButton.addActionListener((ActionEvent e) -> {
            search(searchField.getText());
        });
        JPanel searchPanel = new JPanel();
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        getContentPane().add(searchPanel, BorderLayout.NORTH);

        setVisible(true);
    }

    // Method to update the table with new data
    public void updateTable(List<Itinerary> updatedList) {
        iternityModel.setRowCount(0); // Clear the existing data
        for (Itinerary itinerary : updatedList) {
            Object[] rowData = {
                itinerary.getTrainNumber(),
                itinerary.getDepartureStation(),
                itinerary.getArrivalStation(),
                itinerary.getDepartureTime(),
                itinerary.getArrivalTime(),
                itinerary.getTicketPrice()
            };
            iternityModel.addRow(rowData); // Add new data to the table model
        }
        iternityModel.fireTableDataChanged(); // Notify the table that the data has changed
    }

    private void search(String query) {
        if (query.isEmpty()) {
            updateTable(this.departureSchedule.getIternaryList()); // Display the original data list
            return;
        }

        List<Itinerary> filteredList = new ArrayList<>();
        for (Itinerary itinerary : this.departureSchedule.getIternaryList()) {
            if (itinerary.getTrainNumber().toLowerCase().contains(query.toLowerCase())
                    || itinerary.getDepartureStation().toLowerCase().contains(query.toLowerCase())
                    || itinerary.getArrivalStation().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(itinerary);
            }
        }
        updateTable(filteredList); // Update the table with the filtered data
    }
}
