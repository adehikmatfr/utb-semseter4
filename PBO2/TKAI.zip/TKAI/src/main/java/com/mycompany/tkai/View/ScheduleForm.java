/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tkai.View;

/**
 *
 * @author macbook
 */
import com.mycompany.tkai.Model.Itinerary;
import javax.swing.*;
import java.awt.*;
import java.util.Date;
import com.toedter.calendar.JDateChooser;

public class ScheduleForm extends JFrame {
    private JTextField trainNumberField;
    private JTextField departureStationField;
    private JTextField arrivalStationField;
    private JDateChooser departureTimeChooser;
    private JDateChooser arrivalTimeChooser;
    private JTextField ticketPriceField;
    private JTextField ppnPriceField;
    private MainMenu mainMenu;

    public ScheduleForm(MainMenu mainMenu) {
        this.mainMenu = mainMenu;
        
        setTitle("Schedule Form");
        setSize(400, 300);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); // Center on screen
        setLayout(new GridLayout(8, 2));

        // Train Number
        JLabel trainNumberLabel = new JLabel("Train Number:");
        trainNumberField = new JTextField();
        add(trainNumberLabel);
        add(trainNumberField);

        // Departure Station
        JLabel departureStationLabel = new JLabel("Departure Station:");
        departureStationField = new JTextField();
        add(departureStationLabel);
        add(departureStationField);

        // Arrival Station
        JLabel arrivalStationLabel = new JLabel("Arrival Station:");
        arrivalStationField = new JTextField();
        add(arrivalStationLabel);
        add(arrivalStationField);

        // Departure Time
        JLabel departureTimeLabel = new JLabel("Departure Time:");
        departureTimeChooser = new JDateChooser();
        add(departureTimeLabel);
        add(departureTimeChooser);

        // Arrival Time
        JLabel arrivalTimeLabel = new JLabel("Arrival Time:");
        arrivalTimeChooser = new JDateChooser();
        add(arrivalTimeLabel);
        add(arrivalTimeChooser);

        // Ticket Price
        JLabel ticketPriceLabel = new JLabel("Ticket Price:");
        ticketPriceField = new JTextField();
        add(ticketPriceLabel);
        add(ticketPriceField);
        // PPN
        JLabel ppnPriceLabel = new JLabel("PPN % Price:");
        ppnPriceField = new JTextField();
        ppnPriceField.setEditable(false);
        ppnPriceField.setText("10");
        add(ppnPriceLabel);
        add(ppnPriceField);

        // Submit Button
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(e -> {
            // Get values from form fields
            String trainNumber = trainNumberField.getText();
            String departureStation = departureStationField.getText();
            String arrivalStation = arrivalStationField.getText();
            Date departureTime = departureTimeChooser.getDate();
            Date arrivalTime = arrivalTimeChooser.getDate();
            double ticketPrice = Double.parseDouble(ticketPriceField.getText());
            double ppnPrice = Double.parseDouble(ppnPriceField.getText());
            double finalPrice = (ppnPrice / 100 * ticketPrice)+ticketPrice;

            // Use the data as needed (e.g., save to database, etc.)
            // For now, just print the values
            Itinerary itinerary = new Itinerary(trainNumber, departureStation, arrivalStation, departureTime, arrivalTime, finalPrice);
            this.mainMenu.departureSchedule.addInternary(itinerary);
            this.mainMenu.updateTable(this.mainMenu.departureSchedule.getIternaryList());
            trainNumberField.setText("");
            departureStationField.setText("");
            arrivalStationField.setText("");
            departureTimeChooser.setDate(null);
            arrivalTimeChooser.setDate(null);
            ticketPriceField.setText("");
            
        });
        add(submitButton);

        setVisible(true);
    }
}
