/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tkai.Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author macbook
 */
public class Transaction {
    private List<Ticket> ticketLsit;
    private double totalPrice;

    public Transaction() {
        ticketLsit = new ArrayList<>();
    }

    public void addTranaction(Ticket ticket) {
        ticketLsit.add(ticket);
        this.totalPrice += ticket.getPrice();
    }

    public List<Ticket> getTranactionList() {
        return ticketLsit;
    }

    public void setTrancationList(List<Ticket> ticketList) {
        this.ticketLsit = ticketList;
    }
    
    public double getTotalPrice() {
        return totalPrice;
    }
}
