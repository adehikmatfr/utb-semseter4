/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tkai;
import com.mycompany.tkai.View.LandingPage;
/**
 *
 * @author macbook
 */
public class TKAI {

    public static void main(String[] args) {
        new LandingPage();
    }
}
